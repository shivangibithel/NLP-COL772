# !gdown https://drive.google.com/uc?id=1STTlixkDCgeUMgWqrrYmiwaa3w6B9MFe&export=download
# !unzip assignment_1_data.zip
""" Importing input data """
import json
import string 
import re
import argparse

def read_cli():
    parser = argparse.ArgumentParser(description="Evaluation Script.")

    parser.add_argument(
        "-i", "--input_path",
        help="Input file path",
        required=True, type=str, default="input.json"
    )

    parser.add_argument(
        "-s", "--solution_path",
        help="Solution file path",
        required=True, type=str, default="solution.json"
    )

    args = parser.parse_args()

    return args

def load_json(fname):
    with open(fname, 'r', encoding="utf-8") as fp:
        obj = json.load(fp)

    return obj

# with open('assignment_1_data/input.json','r', encoding="utf-8") as input_file:
#   input_data = json.load(input_file)
#   input_file.close()

# with open('assignment_1_data/output.json','r', encoding="utf-8") as output_file:
#   output_data = json.load(output_file)
#   output_file.close()

number_ones = {0: "o", 1: "one", 2: "two", 3 : "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine"} 

list_puntuations = list(string.punctuation)
list_puntuations.append("—")
# print(list_puntuations)

date = "^([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])(\.|-|/)([1-9]|0[1-9]|1[0-2])(\.|-|/)([0-9][0-9]|19[0-9][0-9]|20[0-9][0-9])$|^([0-9][0-9]|19[0-9][0-9]|20[0-9][0-9])(\.|-|/)([1-9]|0[1-9]|1[0-2])(\.|-|/)([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])$"

# regular expression of time - 12 hr clock system with or without am/pm and 24 hr clock system (does not have am/pm)
time ="^((([0]?[1-9]|1[0-2])((:)[0-5][0-9])?((:)[0-5][0-9])?( )?(AM|am|aM|Am|PM|pm|pM|Pm|p\.m\.|a\.m\.))|(([0]?[0-9]|1[0-9]|2[0-3])(:)[0-5][0-9]((:)[0-5][0-9])?))$"

all_caps = "[A-Z]{1,20}$"

roman_num = "(^(?=[MDCLXVI])M*(C[MD]|D?C{0,3})(X[CL]|L?X{0,3})(I[XV]|V?I{0,3})$)"

yyyy = "^[0-9]{4}$"

frac="(^\-?[0-9]+\/[0-9]+$)|(^\-?[0-9]+\s[0-9]+\/[0-9]+$)"

currency = "^[(\$)|(\£)|(\€)](.*)"
dollor = "^(\$).*"
pounds = "^(\£).*"
euros = "^(\€).*"

isbn = "(^[0-9]+\-[0-9]+\-[0-9]+\-[0-9]+\-[0-9]+$)|(^[0-9]+\s[0-9]+\s[0-9]+\s[0-9]+$)|(^[0-9]{3}\-[0-9]{3}\-[0-9]+$)|(^[0-9]{4}\-[0-9]{1,4}\-[0-9]{1,4}\-*\s*[0-9]{2,4})$"

number = "(^\-?([0-9]*\,*)*\.*[0-9]+$)"
numberth = "(([0-9]*\,*)*[0-9]+st$)|(([0-9]*\,*)*[0-9]+nd$)|(([0-9]*\,*)*[0-9]+th$)"

units = "(km2|km²|ha|K|sec|kg|g|A|mi|km|cm|mA|mm|cr|MB|GB|PG|TB|B|Gb\/s|Mb\/s|Kb\/s)$"
units_dict = {"ha":"hectares","/km2":"per square kilometers","km2":"square kilometers", "/km²":"per square kilometers", "mi":"miles","/km":"per kilometers", "km":"kilometers", "cm":"centimeters", "m":"meters", "mA":"milliamperes", "mm":"millimeters", "A":"amperes",
         "cr":"crore","KB":"kilobytes","MB":"megabytes","GB":"gigabytes","PB":"petabytes","TB":"terabytes","B":"bytes","Gb/s":"gigabits per second","Mb/s":"megabits per second", "K":"Kelvin", "sec":"seconds", "kg":"kilograms","g":"grams","Kb\/s":"kilobits per second"}

months = "((jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec|january|february|march|april|may|june|july|august|september|october|november|december)\s)|(may)"

meter = "^[0-9]+\s?m$"
percent ="(^[0-9]+\s*percent$)|(^[0-9]+\s*pc$)"
minus = "-[0-9]+$"

abbr = {"G. N.":"g n","W.I.":"w i","tv":"t v","MEPs":"m e p's","Yai":"y a i", "Phrao":"p h r a o", "ConnectX-":"c o n n e c t x", "mes":"m e s", "IISi":"i i s i","B-":"b","Nahr":"n a h r", "H. M. G. S.":"h m g s", "USA-":"u s a", "NTApo":"n t a p o","U.S.":"u s","U.S.A.":"u s a","S.A.":"s a"}

abbrevtn = "(Yai)|(Phrao)|(ConnectX-)|(mes)|(IISi)|(B\-)|(Nahr)|(H\.\sM\.\sG\.\sS\.)|(USA\-)|(NTApo)|(MEPs)|(tv)|(W.I.)|(G. N.)|(U.S.)|(U.S.A.)|(S\.A\.)"

""" Conversion Function """

def convert_num(number):
  if bool(re.match("^\-?[0-9]+$",str(number))) == False:
    return " "
  unit_place = ("", "one ", "two ", "three ", "four ","five ", "six ", "seven ","eight ", "nine ", "ten ", "eleven ", "twelve ", "thirteen ", "fourteen ", "fifteen ","sixteen ", "seventeen ", "eighteen ", "nineteen ")
  tens_place =("", "", "twenty ", "thirty ", "forty ", "fifty ","sixty ","seventy ","eighty ","ninety ")

  if number < 0:
      return "minus "+convert_num(-number)

  if number < 20:
      return  unit_place[number] 

  if number < 100:
      return  tens_place[number // 10]  +unit_place[int(number % 10)] 

  if number < 1000:
      return unit_place[number // 100]  +"hundred " +convert_num(int(number % 100))

  if number < 1000000: 
      return  convert_num(number // 1000) + "thousand " + convert_num(int(number % 1000))

  if number < 1000000000:    
      return convert_num(number // 1000000) + "million " + convert_num(int(number % 1000000))

  if number < 1000000000000:    
      return convert_num(number // 1000000000) + "billion " + convert_num(int(number % 1000000000))

  if number < 1000000000000000:    
      return convert_num(number // 1000000000000) + "trillion " + convert_num(int(number % 1000000000000))

  return convert_num(number // 1000000000000000)+ "quadrillion "+ convert_num(int(number % 1000000000000000))

def conv_units(token):
  # if bool(re.match("^\-?([0-9]*\,*)*\.*[0-9]+\s.*[a-zA-Z]+.*$",str(token))) == False:
  #   return "<self>"
  token = token.replace(",","")
  # token = token.replace(".","")
  no_,unit="",""
  li_num = ['1','2','3','4','5','6','7','8','9','0']
  li_token = list(token)
  rupees = 0
  for i in li_token:
    if (unit == "km" and i =="2") or (unit == "/km" and i =="2"):
      unit = unit + i
    elif i in li_num:
      no_ = no_ + i
    elif i == ".":
      no_ = no_ + i
    else:
      if i == " ":
        pass
      elif i == "R":
        rupees = 1
      elif i == "s" and rupees == 1:
        pass
      else:
        unit = unit + i
  no = conv_num(no_)
  uni = units_dict.get(unit)
  if uni:
    wor = no +" "+ uni
  else:
    return "<self>"
  if rupees == 1 and no == "one":
    wor += " rupee"
  elif rupees == 1 and no != "one":
    wor += " rupees"
  elif no == "one":
    wor = wor.strip()
    wor = wor.strip("s")
  elif wor.strip() =="hectares":
    wor = "<self>" 
  return wor

def conv_meter(token):
  token = token.replace(",","")
  no_, unit="", ""
  li_num = ['1','2','3','4','5','6','7','8','9','0']
  li_token = list(token)
  for i in li_token:
    if i in li_num:
      no_ = no_ + i
    elif i == ".":
      decimal = 1
      no_ = no_ + i
    else:
      if i == " ":
        pass
      else:
        unit = unit + i
  no = conv_num(no_)
  if unit == "m":
    unit = units_dict[unit]
  wor = no +" "+ unit
  if no == "one":
    wor = wor.strip()
    wor = wor.strip("s")
  return wor

def conv_num(token):
  token = token.replace(",","")
  no_=""
  li_num = ['-','1','2','3','4','5','6','7','8','9','0']
  decimal = 0
  li_token = list(token)
  for i in li_token:
    if i in li_num:
      no_ = no_ + i
    elif i == ".":
      decimal = 1
      no_ = no_ + i
  if decimal == 1:
    num_dec = no_.split(".")
    if int(num_dec[0]) == 0:
      wor = "zero point "
    else:
      if bool(re.match("^\-?[0-9]+$",str(num_dec[0]))) == False:
        return " "
      wor = convert_num(int(num_dec[0])) + "point "
    frac_dec = list(num_dec[1])
    for j in frac_dec:
      if j == "0" and len(frac_dec) == 1:
        wor += "zero"
      elif j == "0" and len(frac_dec) != 1:
        wor += "o "
      if bool(re.match("^\-?[0-9]+$",str(j))) == False:
        return " "
      wor += convert_num(int(j))
  else:
    if bool(re.match("^\-?[0-9]+$",str(no_))) == False:
        return " "
    wor = convert_num(int(no_))
  return wor.strip()

def conv_date(token):
  dictm = {"1":"january","2":"february","3":"march","4":"april","5":"may","6":"june","7":"july","8":"august","9":"september","10":"october",11:"november",12:"december",
           "01":"january","02":"february","03":"march","04":"april","05":"may","06":"june","07":"july","08":"august","09":"september"}

  dictm2 = {"1":"first", "2":"second", "3":"third", "4":"fourth", "5":"fifth", "6":"sixth", "7":"seventh", "8":"eighth", "9":"ninth",
            "01":"first", "02":"second", "03":"third", "04":"fourth", "05":"fifth", "06":"sixth", "07":"seventh", "08":"eighth", "09":"ninth",
            "10":"tenth","11":"eleventh","12":"twelfth", "13":"thirteenth", "14": "fourteenth", "15": "fifteen", "16":"sixteen", "17": "seventeen",
            "18": "eighteen", "19": "nineteen","20":"twentieth","21":"twenty first", "22":"twenty second", "23":"twenty third", "24":"twenty fourth",
            "25":"twenty fifth","26":"twenty sixth","27":"twenty seventh","28":"twenty eighth","29":"twenty ninth","30": "thirtieth","31":"thirty first"}
  tok = token.split("-")
  wor,mon = "", ""
  for i in range(len(tok)):
    if bool(re.match(yyyy,tok[i])):
      year = int(tok[i])
      if year == 1200:
        yr = "twelve hundred"
      elif year == 1201:
        yr = "twelve o one"
      elif year == 1806:
        yr = "eighteen o six" 
      elif year == 1601:
        yr = "sixteen o one"     
      elif (year > 1999 and year < 2010) or (year > 1899 and year < 1910):
        yr = convert_num(year).strip()
      else:
        y = tok[i]
        y_words = convert_num(int(y[0:2])) + convert_num(int(y[2:4]))
        yr = y_words.strip()
    if i!=0 and wor !="":
      if i==1:
        mon = dictm[tok[i]]
      elif i==2:
        wor ="the "+ dictm2[tok[i]] +" of "
    wor = wor + mon + " " + yr
  return wor

def conv_months(token):
  token = token.replace(",","")
  dictm = {"1":"january","2":"february","3":"march","4":"april","5":"may","6":"june","7":"july","8":"august","9":"september","10":"october",11:"november",12:"december",
           "01":"january","02":"february","03":"march","04":"april","05":"may","06":"june","07":"july","08":"august","09":"september"}

  dictm2 = {"1":"first", "2":"second","2nd":"second", "3":"third", "4":"fourth", "5":"fifth", "6":"sixth", "7":"seventh", "8":"eighth", "9":"ninth",
            "01":"first", "02":"second", "03":"third", "04":"fourth", "05":"fifth", "06":"sixth", "07":"seventh", "08":"eighth", "09":"ninth",
            "10":"tenth","11":"eleventh","12":"twelfth", "13":"thirteenth", "14": "fourteenth", "15": "fifteenth", "16":"sixteenth", "17": "seventeenth",
            "18": "eighteenth", "19": "nineteenth","20":"twentieth","21":"twenty first", "22":"twenty second", "23":"twenty third", "24":"twenty fourth",
            "25":"twenty fifth","26":"twenty sixth","27":"twenty seventh","28":"twenty eighth","29":"twenty ninth","30": "thirtieth","31":"thirty first"}
  tok = token.split(" ")
  day,mon,wor,yr = "","", "",""
  pos_day, pos_mon, pos_yr =0,0,0
  for i in range(len(tok)):
    if bool(re.match(yyyy,tok[i])):
      year = int(tok[i])
      last_digit = int(tok[i][-1])
      first_digits = int(tok[i][:2])
      if tok[i][-2:] == "00" and first_digits != 20:
        yr = convert_num(int(first_digits))+"hundred"
      elif tok[i][2] == "0" and last_digit <= 9 and last_digit >= 1 and first_digits != 20:
        yr = convert_num(int(first_digits))+"o " + convert_num(int(last_digit)).strip()    
      elif (year > 1999 and year < 2010):
        yr = convert_num(year).strip()
      else:
        y = tok[i]
        y_words = convert_num(int(y[0:2])) + convert_num(int(y[2:4]))
        yr = y_words.strip()
      pos_yr = i
    elif bool(re.match("(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec|january|february|march|april|may|june|july|august|september|october|november|december)",tok[i].lower())):
      mon = tok[i].lower()
      pos_mon =i
    elif bool(re.match("[0-9]{1,2}",tok[i])):
      day = dictm2[tok[i]]
      pos_day =i
  if pos_day == 0  and pos_mon == 1 and pos_yr ==2:
    wor = "the "+ day+ " of "+ mon +" " +yr
  if pos_day == 0  and pos_mon == 1 and pos_yr ==0:
    wor = "the "+ day+ " of "+ mon
  if pos_day == 1  and pos_mon == 0 and pos_yr ==2:
    wor =  mon +" " +day + " " +yr
  if pos_day == 0  and pos_mon == 0 and pos_yr ==1:
    wor =  mon +" " +yr
  if pos_day == 1  and pos_mon == 0 and pos_yr ==0:
    wor =  mon +" " +day
  if pos_day == 0  and pos_mon == 0 and pos_yr ==0:
    wor =  mon
  return wor

def conv_numth(token):
  dictm={"1":"first", "2":"second", "3":"third", "4":"fourth", "5":"fifth", "6":"sixth", "7":"seventh", "8":"eighth", "9":"ninth",
            "10":"tenth","11":"eleventh","12":"twelfth", "13":"thirteenth", "14": "fourteenth", "15": "fifteenth", "16":"sixteenth", "17": "seventeenth",
            "18": "eighteenth", "19": "nineteenth","20":"twentieth"}
  dictm2 ={20:"twentieth", 30: "thirtieth", 40: "fortieth", 50: "fiftieth", 60: "sixtieth", 70: "seventieth", 80:"eightieth", 90: "ninetieth", 100:"hundredth"}
  tok = list(token)
  no_,wor="",""
  for i in tok:
    if i in ['1','2','3','4','5','6','7','8','9','0']:
      no_ += i
    else:
      wor += i
  if int(no_)<=20:
    return dictm[no_]
  else:
    ans = convert_num(int(no_))
    ans = ans.strip()
    ans = ans.split(" ")
    ans.pop()
    if no_[-1] == "0":
      ans.append(dictm2[int(no_[-2:])])
    else:
      ans.append(dictm[no_[-1]])
    ans = " ".join(ans)
    return ans 

def conv_frac(token):
  frac_dict_0 = {2:"half", 3:"third", 4:"fourth", 5:"fifth", 6:"sixth", 7:"seventh", 8:"eighth", 9:"ninth"}
  frac_dict_1 = {2:"half", 3:"thirds", 4:"fourths", 5:"fifths", 6:"sixths", 7:"sevenths", 8:"eighths", 9:"ninths"}
  frac_dict_2 = {10:"tenth",11:"eleventh",12:"twelfth", 13:"thirteenth", 14: "fourteenth", 15: "fifteen", 16:"sixteen", 17: "seventeen", 18: "eighteen", 19: "nineteen",
                 20:"twentieth", 30: "thirtieth", 40: "fortieth", 50: "fiftieth", 60: "sixtieth", 70: "seventieth", 80:"eightieth", 90: "ninetieth", 100:"hundredth" }
  frac_dict_3 = {10:"tenths",11:"elevenths",12:"twelfths", 13:"thirteenths", 14: "fourteenths", 15: "fifteenths", 16:"sixteenths", 17: "seventeenths", 18: "eighteenths", 19: "nineteenths" ,
                 20:"twentieths", 30: "thirtieths", 40: "fortieths", 50: "fiftieths", 60: "sixtieths", 70: "seventieths", 80:"eightieths", 90: "ninetieths", 100:"hundredths"}
  
  if bool(re.match("(^\-?[0-9]+\s[0-9]+\/[0-9]+$)",token)):    
    t = token.split(" ")
    wor = convert_num(int(t[0])) + "and "
    if t[1]=="1/2":
      wor = wor + "a half"
    else:
      k = t[1].split("/")
      wor += convert_num(int(k[0]))
      if len(k[1]) == 1 and int(k[0]) == 1:
        if (int(k[1]) == 4):
          wor += "quarters"
        else:
          wor += frac_dict_0[int(k[1])]
      elif len(k[1]) == 1 and int(k[0]) > 1:
        if(int(k[1]) == 4):
          wor += "quarters"
        else:
          wor += frac_dict_1[int(k[1])]
      elif int(k[1]) in [10,11,12,13,14,15,16,17,18,19,20,30,40,50,60,70,80,90,100] and int(k[0]) == 1:
        wor += frac_dict_2.get(int(k[1]))
      elif int(k[1]) in [10,11,12,13,14,15,16,17,18,19,20,30,40,50,60,70,80,90,100] and int(k[0]) > 1:
        wor += frac_dict_3.get(int(k[1]))
      else:
        q = k[1][-1]
        if k[1][-1] == "0":
          q = k[1][-2:]
        y = convert_num(int(k[1]))
        y_list = y.split(" ")
        for m in range(len(y_list)-1):
          wor = wor + y_list[m] + " "
        if int(q) in [2,3,4,5,6,7,8,9]:
          wor += frac_dict_1.get(int(q))
        elif int(q) in [10,11,12,13,14,15,16,17,18,19,20,30,40,50,60,70,80,90,100]:
          wor += frac_dict_3.get(int(q))
  else:
    k = token.split("/")
    wor = convert_num(int(k[0]))
    if len(k[1]) == 1 and int(k[0]) == 1:
        if(int(k[1]) == 4):
          wor += "quarters"
        else:
          wor += frac_dict_0[int(k[1])]
    elif len(k[1]) == 1 and int(k[0]) > 1:
      if (int(k[1]) == 4):
          wor += "quarters"
      else:
        wor += frac_dict_1[int(k[1])]
    elif int(k[1]) in [10,11,12,13,14,15,16,17,18,19,20,30,40,50,60,70,80,90,100] and int(k[0]) == 1:
      wor += frac_dict_2[int(k[1])]
    elif int(k[1]) in [10,11,12,13,14,15,16,17,18,19,20,30,40,50,60,70,80,90,100] and int(k[0]) > 1:
      wor += frac_dict_3[int(k[1])]
    else:
      q = k[1][-1]
      if q == "0":
        q = k[1][-2:]
      y = convert_num(int(k[1]))
      y_list = y.split(" ")
      for m in range(len(y_list)-2):
        wor = wor + y_list[m] + " "
      if int(q) in [2,3,4,5,6,7,8,9]:
          wor += frac_dict_1[int(q)]
      elif int(q) in [10,11,12,13,14,15,16,17,18,19,20,30,40,50,60,70,80,90,100]:
        wor += frac_dict_3[int(q)]
  return wor

def conv_isbn(token):
  wor = ""
  if bool(re.match("([0-9]+\-[0-9]+\-[0-9]+\-[0-9]+\-[0-9]+)|([0-9]{3}\-[0-9]{3}\-[0-9]+)",token)):
    t = list(token)    
    for i in t:
      if i == "0":
        wor = wor + "o "
      elif i == "-":
        wor += "sil "
      else:
        wor += convert_num(int(i))
  elif bool(re.match("([0-9]+\s[0-9]+\s[0-9]+\s[0-9]+)",token)):
    t = list(token)
    for i in t:
      if i == "0":
        wor = wor + "o "
      elif i == " ":
        wor += "sil "
      else:
        wor += convert_num(int(i))
  elif bool(re.match("([0-9]{4}\-[0-9]{1,4}\-[0-9]{1,4}\-*\s*[0-9]{2,4})",token)):
    # print(token)
    t = list(token)
    for i in t:
      if i == "0":
        wor = wor + "o "
      elif i == " " or i =="-":
        wor += "sil "
      else:
        wor += convert_num(int(i))
  return wor

def isbn_fun(token):
  no = ""
  li_num = ['1','2','3','4','5','6','7','8','9']
  t = token
  for char in t:
    if char in li_num:
      no = no + convert_num(int(char))
    elif char =="0":
      no += "o "
    elif char in list_puntuations or char == " ":
      no = no + "sil "
  if no.strip() == "":
    return "<self>"
  return no.strip()

def conv_currency(token):
  token = token.strip(",")
  if bool(re.match(dollor,token)):
    token = token.strip("$")
    word = currToWord(token) 
    word = word.strip()
    if word == "one" or word == "one million" or word == "one billion" or word == "one trillion" or word == "one hundred" or word == "one thousand" :
      word += " dollar"
    else:
      word += " dollars"
  elif bool(re.match(pounds,token)):
    token = token.strip("£")
    word = currToWord(token) 
    word = word.strip()
    if word == "one" or word == "one million" or word == "one billion" or word == "one trillion" or word == "one hundred" or word == "one thousand":
      word += " pound"
    else:
      word += " pounds"
  elif bool(re.match(euros,token)):
    token = token.strip("€")
    word = currToWord(token) 
    word = word.strip()
    if word == "one" or word == "one million" or word == "one billion" or word == "one trillion" or word == "one hundred" or word == "one thousand":
      word += " euro"
    else:
      word += " euros"
  return word

def currToWord(token):
  li_num = ['1','2','3','4','5','6','7','8','9','0']
  token_list = list(token)
  n=""
  million_flag, billion_flag, trillion_flag,decimal_flag = 0, 0, 0, 0
  for j in token_list:
    if j in li_num:
      n = n +  str(j)
    elif j ==".":
      decimal_flag = 1
      n = n + str(j)
      # handle decimal
    elif j == " ":
      pass
    elif j.lower() == "m":
      million_flag = 1
      break
    elif j.lower() == "b":
      billion_flag = 1
      break
    elif j.lower() == "t":
      trillion_flag = 1
      break
  n = n.strip() 
  wor = "" 
  if decimal_flag:
    tok = n.split(".")
    if bool(re.match("^\-?[0-9]+$",str(tok[0]))) == False or bool(re.match("^\-?[0-9]+$",str(tok[1]))) == False:
      return " "
    wor = convert_num(int(tok[0])) + "point "+ convert_num(int(tok[1]))
  else:
    if bool(re.match("^\-?[0-9]+$",str(n))) == False:
      return " "
    wor = convert_num(int(n))
  if million_flag:
    wor = wor + "million"
  elif billion_flag:
    wor = wor + "billion"
  elif trillion_flag:
    wor = wor + "trillion"
  return wor

# Handling Roman Numbers 
def romanToNumber(t):
  roman_dict = {'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000,'IV':4,'IX':9,'XL':40,'XC':90,'CD':400,'CM':900}
  i = 0
  number = 0
  while i < len(t):
      if i+1<len(t) and t[i:i+2] in roman_dict:
        number = number + roman_dict[t[i:i+2]]
        i+=2
      else:
        number = number + roman_dict[t[i]]
        i+=1
  return number
def romanToWord(num):
  words = convert_num(num)
  return words.lower()
def romanToWords(num):
  dict_words = {1:"first", 2:"second", 3:"third", 4:"fourth", 5:"fifth", 6:"sixth", 7:"seventh", 8:"eighth", 9:"ninth", 10:"tenth"}
  words = "the " + dict_words[num]
  return words.lower()

def conv_time(t):
  if bool(re.match("^[0-9]{1,2}\:00$",t)):
    x = t.split(":")
    ans = ""
    if x[0] == "00" or x[0] == "0":
      ans = "zero hundred"
      return ans
    elif int(x[0]) > 12:
      ans = convert_num(int(x[0])) + "hundred"
      return ans
    else:
      ans = convert_num(int(x[0])) + "o'clock"
      return ans
  am_count,pm_count = 0,0
  if t.endswith("AM") or t.endswith("am") or t.endswith("Am") or t.endswith("aM") or t.endswith("a.m.") :
    am_count = 1
  if t.endswith("PM") or t.endswith("pm") or t.endswith("Pm") or t.endswith("pM") or t.endswith("p.m.") :
    pm_count = 1
  t = re.sub(r'(AM|am|aM|Am|a\.m\.)', "", t)
  t = re.sub(r'(PM|pm|pM|Pm|p\.m\.)', "", t) 
  li = re.split(':',t)
  words=" "
  if len(li)==3:
    for i in range(len(li)):
      n = int(li[i])
      wo = convert_num(n)
      if wo != "zero":
        if i == 0:
          words = words +  wo + "hours "
        elif i == 1:
          words = words +  wo + "minutes "
        elif i == 2:
          words = words + "and " + wo + "seconds"
  else:
    for i in li:
      i = int(i)
      wo = convert_num(i).lower()
      if wo != "zero":
        words = words +  wo
  if am_count == 1:
    words = words +  "a m"
  if pm_count ==1:
    words = words +  "p m"
  return words.strip()

def conv_AllCaps(t):
  output= ""
  t = t.lower()
  for char in t:
    output = output + char + ' '
  return output

"""Generating the output"""


def solution(input_tokens):
  count = 0
  orignal_tokens = input_tokens.copy()
  for i in range(len(input_tokens)):
    # puntuations --> sil
    if input_tokens[i] in list_puntuations:
      input_tokens[i] = 'sil'
    # A., F. --> a, f
    elif bool(re.match("^[A-Z]\.$",input_tokens[i])): 
      input_tokens[i] = input_tokens[i].strip(".").lower()
    # Decimal/Non-decimal percetnage
    elif bool(re.match("(^[0-9]+\.[0-9]+\%$)|(^[0-9]+\%$)",input_tokens[i].replace(" ",""))):
      input_tokens[i] = input_tokens[i].replace(" ","")
      input_tokens[i] = input_tokens[i].strip()
      if bool(re.match("^[0-9]+\.[0-9]+\%$",input_tokens[i])):
        dec = input_tokens[i].strip("%").split(".")
        no = list(dec[1])
        no_=""
        for l in no:
          no_ = no_ + " "+ number_ones[int(l)]
        if int(dec[0]) == 0:
          no_ = "zero point" + no_ +" percent"
        else:
          no_ = convert_num(int(dec[0])) + "point" + no_ +" percent"
        input_tokens[i] = no_.strip()
      else:
        input_tokens[i] = input_tokens[i].strip("%")
        input_tokens[i] = convert_num(int(input_tokens[i])).lower().strip() + " percent"
    # time
    elif bool(re.match(time,input_tokens[i].strip())):
      input_tokens[i] = conv_time(input_tokens[i].strip())
    # roman numerals
    elif bool(re.match(roman_num,input_tokens[i])):
      romanToNum = romanToNumber(input_tokens[i])
      if orignal_tokens[i-1] == "Chapter" or orignal_tokens[i-2] == "Lincoln":
        input_tokens[i] = romanToWord(romanToNum).strip()
      elif orignal_tokens[i-1] =="promotional" and input_tokens[i]=="CD":
        input_tokens[i]="c d"
      elif bool(re.match("^[A-Z]",orignal_tokens[i-1])):          
        input_tokens[i] = romanToWords(romanToNum).strip()
      else:
        input_tokens[i] = romanToWord(romanToNum).strip()
    # handle all caps 
    elif bool(re.match(all_caps,input_tokens[i])):
      input_tokens[i] = conv_AllCaps(input_tokens[i]).strip()
    # YYYY
    elif bool(re.match(yyyy,input_tokens[i])):
      year = int(input_tokens[i])
      last_digit = int(input_tokens[i][-1])
      first_digits = int(input_tokens[i][:2])
      if input_tokens[i][-2:] == "00" and first_digits != 20:
        input_tokens[i] = convert_num(int(first_digits))+"hundred"
      elif input_tokens[i][2] == "0" and last_digit <= 9 and last_digit >= 1 and first_digits != 20:
        input_tokens[i] = convert_num(int(first_digits))+"o " + convert_num(int(last_digit)).strip()    
      elif (year > 1999 and year < 2010):
        input_tokens[i] = convert_num(year).strip()
      else:
        y = input_tokens[i]
        y_words = convert_num(int(y[0:2])) + convert_num(int(y[2:4]))
        input_tokens[i] = y_words.strip()
    # currency
    elif bool(re.match(currency,input_tokens[i])):
      input_tokens[i] = conv_currency(input_tokens[i]).strip()
    elif orignal_tokens[i-1] =="ISBN" or orignal_tokens[i-1] =="I.S.B.N.":
      input_tokens[i] = isbn_fun(input_tokens[i]).strip()
    elif bool(re.match(isbn,input_tokens[i])):
      input_tokens[i] = conv_isbn(input_tokens[i]).strip()
    elif bool(re.match(frac,input_tokens[i])):
      input_tokens[i] = conv_frac(input_tokens[i]).strip()
    elif bool(re.match(date,input_tokens[i])):
      input_tokens[i] = conv_date(input_tokens[i]).strip()
    elif bool(re.search(months,input_tokens[i].lower().strip("."))):
      input_tokens[i] = conv_months(input_tokens[i]).lower().strip(".")
    elif bool(re.search(units,input_tokens[i])):
      input_tokens[i] = conv_units(input_tokens[i]).strip()
    elif bool(re.match(meter,input_tokens[i])):
      input_tokens[i] = conv_meter(input_tokens[i]).strip()
    elif bool(re.match(number,input_tokens[i].strip())):
      input_tokens[i] = conv_num(input_tokens[i].strip()).strip()
    elif bool(re.match(numberth,input_tokens[i])):
      input_tokens[i] = conv_numth(input_tokens[i]).strip()
    elif bool(re.match(abbrevtn,input_tokens[i])):
      input_tokens[i] = abbr.get(input_tokens[i])
    elif bool(re.match(percent,input_tokens[i].strip())):
      input_tokens[i] = input_tokens[i].strip()
      c = list(input_tokens[i])
      no_ =""
      for l in c:
        if l in ['1','2','3','4','5','6','7','8','9','0']:
          no_ = no_+ l
        elif l ==" ":
          pass
      input_tokens[i] = convert_num(int(no_))+"percent"
    else:
      input_tokens[i]='<self>'
    if bool(re.match("^[A-Z]{1}$",orignal_tokens[i])):
      input_tokens[i]='<self>'
  return input_tokens

def solution_dump(solution_file_path):
  input_data = load_json(args.input_path)
  solution_data = []
  for input_sentence in input_data:
    solution_sid = input_sentence['sid']
    solution_tokens = solution(input_sentence['input_tokens'])
    solution_data.append({'sid':solution_sid,
                          'output_tokens':solution_tokens})

  with open(args.solution_path,'w') as solution_file:
    json.dump(solution_data, solution_file, indent=2, ensure_ascii=False)
    solution_file.close()

if __name__ == '__main__':
  args = read_cli()
  solution_dump('solution.json')
  

