import sys
import re
#import contractions
import nltk
import unicodedata
import pandas as pd
import pickle
import sklearn
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings("ignore")
import time
from sklearn import preprocessing
from scipy import stats
from sklearn.utils import shuffle
from nltk.corpus import stopwords
import string
import argparse

def read_cli():
    parser = argparse.ArgumentParser(description="test")

    parser.add_argument(
        "-model", "--model_dir",
        help="model directory",
        required=True, type=str, default="./model"
    )
    
    parser.add_argument(
        "-i", "--input_file",
        help="input_file_path",
        required=True, type=str, default="./inputfile.txt"
    )
    
    parser.add_argument(
        "-o", "--output_file",
        help="output_file_path",
        required=True, type=str, default="./outputfile.txt"
    )

    args = parser.parse_args()
    return args

def cleaning(text):
  try:
    text = str(text)
    text= text.lower()
    #text= emoji.demojize(text)
    #text=contractions.fix(text)
    not_ = re.compile(r"\b(no{1,3}t{1,3}|shouldn't|wouldn't|can't|won't|no{1,3}|never{1,3}|haven't|hasn't|cannot|didn't|don't|isn't|ain't)\b")
    text = not_.sub("not", text)
    text = text.replace("&amp;", "and").replace("&gt;", "greater than").replace("&lt;", "smaller than")
    text=text.strip()
    text=text.replace('[^\w\s]','')
    text=re.sub(r'http\S+', '', text)
    removed_punct = re.compile('[/(){}\[\]\|@,;]')
    remove_extra = re.compile('[^0-9a-z +]')
    text = removed_punct.sub(' ' , text)
    text = remove_extra.sub(' ',text)   
    return text
  except:
    return " "
  
 
def Vectorize(vec, X_test):
  X_test_vec = vec.fit_transform(X_test)
  return X_test_vec


if __name__=="__main__":
  args = read_cli()
  inp = args.input_file
  out = args.output_file
  modeldir = args.model_dir
  data = pd.read_csv(inp, names=["tweet"])
  data['tweet_cleaned'] = data['tweet'].apply(cleaning)
  X = data.tweet_cleaned 
  dictionary = modeldir + "/tfidf.pkl"
  tf = pickle.load(open(dictionary,'rb'))
  X1 = data.tweet
  try:
      X_test_vec_tfidf = Vectorize(TfidfVectorizer(binary = True, ngram_range = (1,2),vocabulary = tf.vocabulary_), X)
  except:
      X=X1
      X_test_vec_tfidf = Vectorize(TfidfVectorizer(binary = True, ngram_range = (1,2),vocabulary = tf.vocabulary_), X)
  
  filename = modeldir + "/MultinomialNB.sav"
  model2 = pickle.load(open(filename, 'rb'))
  filename = modeldir + "/LogisticRegression.sav"
  model3 = pickle.load(open(filename, 'rb'))
  filename = modeldir + "/LinearSVC.sav"
  model4 = pickle.load(open(filename, 'rb'))
  
  pred2=model2.predict(X_test_vec_tfidf)
  pred3=model3.predict(X_test_vec_tfidf)
  pred4=model4.predict(X_test_vec_tfidf)

  
  final_pred = []
  textfile = open(out, "w")
  for i in range(len(X)):
      final_pred.append(stats.mode([ pred2[i], pred3[i], pred4[i]]))
  for element in final_pred:
    textfile.write(str(element[0][0]) + "\n")
  
  

  