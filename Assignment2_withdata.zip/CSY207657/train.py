import sys
import re
#import contractions
import nltk
import unicodedata
import pandas as pd
import pickle
import sklearn
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings("ignore")
import time
from sklearn import preprocessing
from scipy import stats
from sklearn.utils import shuffle
from nltk.corpus import stopwords
import string
import argparse

def read_cli():
    parser = argparse.ArgumentParser(description="train")

    parser.add_argument(
        "-data", "--data_dir",
        help="data directory",
        required=True, type=str, default="./data"
    )

    parser.add_argument(
        "-model", "--model_dir",
        help="model directory",
        required=True, type=str, default="./model"
    )

    args = parser.parse_args()
    return args

def cleaning(text):
  try:
    text = str(text)
    text= text.lower()
    #text= emoji.demojize(text)
    #text=contractions.fix(text)
    not_ = re.compile(r"\b(no{1,3}t{1,3}|shouldn't|wouldn't|can't|won't|no{1,3}|never{1,3}|haven't|hasn't|cannot|didn't|don't|isn't|ain't)\b")
    text = not_.sub("not", text)
    text = text.replace("&amp;", "and").replace("&gt;", "greater than").replace("&lt;", "smaller than")
    text=text.strip()
    text=text.replace('[^\w\s]','')
    text=re.sub(r'http\S+', '', text)
    removed_punct = re.compile('[/(){}\[\]\|@,;]')
    remove_extra = re.compile('[^0-9a-z +]')
    text = removed_punct.sub(' ' , text)
    text = remove_extra.sub(' ',text)  
    return text
  except:
    return " "
    
def Vectorize(vec, X_train):
    tf_ = vec.fit(X_train) 
    X_train_vec = vec.transform(X_train)
    dictionary = modeldir + "/tfidf.pkl"
    pickle.dump(tf_, open(dictionary, "wb"))
    return X_train_vec

if __name__=="__main__":
    args = read_cli()
    modeldir = args.model_dir
    filename = args.data_dir+ "/training.csv"
    #stop_words = set(stopwords.words('english'))
    try:
      data = pd.read_csv(filename,sep=',',names = ["label","tweet"] , encoding='latin-1')
      data['tweet_cleaned'] = data['tweet'].apply(cleaning)
      data = shuffle(data)
      X = data.tweet_cleaned  
      data['label']= data['label'].astype(int)
      y = data.label
      X1 = data.tweet
    except:
      data = pd.read_csv(filename,sep=',', encoding='latin-1')
      data['tweet_cleaned'] = data['tweet'].apply(cleaning)
      data = shuffle(data)
      X = data.tweet_cleaned  
      data['label']= data['label'].astype(int)
      y = data.label
      X1 = data.tweet
        
    
    try:
        X_train_vec_tfidf = Vectorize(TfidfVectorizer(binary = True, ngram_range = (1,2)), X)
    except:
        X_train_vec_tfidf = Vectorize(TfidfVectorizer(binary = True, ngram_range = (1,2)), X1)
    
    model2=  MultinomialNB(alpha = 5)
    model2.fit(X_train_vec_tfidf,y)
    filename = modeldir + "/MultinomialNB.sav"
    pickle.dump(model2, open(filename, 'wb'))
    
    model3= LogisticRegression(random_state=0,penalty="l2",solver="saga")
    model3.fit(X_train_vec_tfidf,y)
    filename = modeldir + "/LogisticRegression.sav"
    pickle.dump(model3, open(filename, 'wb'))

    model4= LinearSVC(loss = "hinge",random_state=0,class_weight ="balanced")
    model4.fit(X_train_vec_tfidf,y)
    filename = modeldir + "/LinearSVC.sav"
    pickle.dump(model4, open(filename, 'wb'))
